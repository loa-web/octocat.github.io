
INSTALLATION

1. Installer Node.js

https://nodejs.org

2. Ouvrir CMD dans le dossier

3. Installer dépendances :

npm install

4. Lancer serveur :

npm start

5. Ouvrir :

http://localhost:3000

--------------------------------

IMPORTANT

Le système actuel est une DEMO.

Pour vrai paiement crypto :
- OxaPay
- CryptoMus
- NOWPayments

Tu devras :
- mettre clé API
- mettre webhook
- héberger sur VPS

--------------------------------

AUTO LIVRAISON

Le produit est livré automatiquement après validation paiement.

Stock :
server.js

Tu peux remplacer :
KFC_ACCOUNT_001

par :
- comptes
- codes
- clés
- liens
