
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

let orders = [];
let stock = [
  "KFC_ACCOUNT_001",
  "KFC_ACCOUNT_002",
  "KFC_ACCOUNT_003"
];

// CREATE PAYMENT
app.post('/api/create-payment', (req, res) => {

  const { product, amount, userId } = req.body;

  const orderId = 'ORDER_' + Date.now();

  // SIMULATION PAYMENT
  const fakeWallet = "0xKFCAUTO123456789";

  orders.push({
    orderId,
    product,
    amount,
    userId,
    paid:false,
    delivered:false,
    delivery:null
  });

  res.json({
    success:true,
    orderId,
    wallet:fakeWallet,
    qr:"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data="+fakeWallet
  });
});

// VERIFY PAYMENT AUTO
app.post('/api/verify-payment', (req, res) => {

  const { orderId } = req.body;

  const order = orders.find(x=>x.orderId===orderId);

  if(!order){
    return res.status(404).json({error:true});
  }

  // AUTO VALIDATION DEMO
  order.paid = true;

  // AUTO DELIVERY
  if(!order.delivered){

    const product = stock.shift();

    order.delivery = product;
    order.delivered = true;
  }

  res.json({
    paid:order.paid,
    delivered:order.delivered,
    product:order.delivery
  });
});

app.get('/api/order/:id',(req,res)=>{

  const order = orders.find(x=>x.orderId===req.params.id);

  if(!order){
    return res.status(404).json({error:true});
  }

  res.json(order);
});

app.listen(3000,()=>{
  console.log('SERVER ONLINE http://localhost:3000');
});
